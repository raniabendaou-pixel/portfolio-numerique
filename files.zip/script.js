/* ==========================================================
   Portfolio numérique : script commun à toutes les pages.
   Chaque fonctionnalité ne s'active que si son élément
   existe dans la page (ex. le quiz seulement sur
   cybersecurite.html).
   ========================================================== */
(function () {
  "use strict";

  const $ = (selector, parent = document) => parent.querySelector(selector);
  const $$ = (selector, parent = document) => [...parent.querySelectorAll(selector)];

  // Lecture / écriture dans le navigateur (localStorage), sans planter si indisponible
  const store = {
    get(key, fallback) {
      try {
        const value = localStorage.getItem(key);
        return value === null ? fallback : JSON.parse(value);
      } catch (e) {
        return fallback;
      }
    },
    set(key, value) {
      try {
        localStorage.setItem(key, JSON.stringify(value));
      } catch (e) {
        /* stockage indisponible : on ignore */
      }
    },
  };

  /* ---------- 1. Thème clair / sombre ---------- */
  const root = document.documentElement;
  const themeBtn = $(".theme-btn");

  function applyTheme(theme) {
    root.setAttribute("data-theme", theme);
    if (themeBtn) {
      const dark = theme === "dark";
      themeBtn.setAttribute("aria-pressed", String(dark));
      themeBtn.textContent = dark ? "Mode clair" : "Mode sombre";
    }
  }

  const savedTheme = store.get("theme", null);
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  applyTheme(savedTheme || (prefersDark ? "dark" : "light"));

  if (themeBtn) {
    themeBtn.addEventListener("click", () => {
      const next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
      applyTheme(next);
      store.set("theme", next);
    });
  }

  /* ---------- 2. Menu mobile ---------- */
  const menuBtn = $(".menu-btn");
  const menu = $("#menu");

  function setMenu(open) {
    menu.classList.toggle("open", open);
    menuBtn.setAttribute("aria-expanded", String(open));
  }

  if (menuBtn && menu) {
    menuBtn.addEventListener("click", () => setMenu(!menu.classList.contains("open")));
    $$("a", menu).forEach((link) => link.addEventListener("click", () => setMenu(false)));
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") setMenu(false);
    });
  }

  /* ---------- 3. Année dans le pied de page ---------- */
  const year = $("#year");
  if (year) year.textContent = new Date().getFullYear();

  /* ---------- 4. Avancement du portfolio (page d'accueil) ---------- */
  function initProgress() {
    const checks = $$("input[data-page]");
    const fg = $(".ring-fg");
    if (!checks.length || !fg) return;

    const label = $("#ring-label");
    const caption = $("#ring-caption");
    const resetBtn = $("#reset-progress");
    const radius = 52;
    const circumference = 2 * Math.PI * radius;
    fg.style.strokeDasharray = String(circumference);

    const done = new Set(store.get("pages-terminees", []));
    checks.forEach((box) => (box.checked = done.has(box.dataset.page)));

    function update() {
      const count = checks.filter((box) => box.checked).length;
      const ratio = count / checks.length;
      fg.style.strokeDashoffset = String(circumference * (1 - ratio));
      label.textContent = count + "/" + checks.length;
      caption.textContent = count === checks.length
        ? "Toutes les pages sont terminées."
        : "pages terminées sur " + checks.length;
      store.set("pages-terminees", checks.filter((box) => box.checked).map((box) => box.dataset.page));
    }

    checks.forEach((box) => box.addEventListener("change", update));
    resetBtn.addEventListener("click", () => {
      checks.forEach((box) => (box.checked = false));
      update();
    });
    update();
  }

  /* ---------- 5. Quiz « Suis-je bien protégé ? » (cybersecurite.html) ---------- */
  // Tu peux modifier, ajouter ou supprimer des questions ici.
  // "answer" = numéro de la bonne réponse (la première réponse a le numéro 0).
  const QUESTIONS = [
    {
      q: "Un e-mail de ta banque te demande de « confirmer ton mot de passe » via un lien, avec une menace de blocage sous 24 h. Que fais-tu ?",
      options: [
        "Je clique vite sur le lien pour éviter le blocage.",
        "Je n'utilise pas le lien : je tape moi-même l'adresse officielle de ma banque.",
        "Je réponds à l'e-mail avec mon mot de passe.",
      ],
      answer: 1,
      why: "C'est un schéma classique d'hameçonnage : l'urgence et la menace servent à te faire cliquer sans réfléchir.",
    },
    {
      q: "Quel mot de passe est le plus robuste ?",
      options: ["azerty123", "Prenom2005", "Une phrase longue, unique pour ce site"],
      answer: 2,
      why: "La longueur compte plus que la complexité apparente, et un mot de passe unique évite l'effet domino si un site est piraté.",
    },
    {
      q: "À quoi sert l'authentification à deux facteurs (2FA) ?",
      options: [
        "À chiffrer le Wi-Fi.",
        "À demander une seconde preuve d'identité en plus du mot de passe.",
        "À se connecter plus vite.",
      ],
      answer: 1,
      why: "Même si ton mot de passe est volé, l'attaquant a encore besoin du second facteur (code, application, clé de sécurité).",
    },
    {
      q: "Quel logiciel malveillant chiffre tes fichiers puis réclame une rançon ?",
      options: ["Un spyware", "Un ransomware", "Un ver"],
      answer: 1,
      why: "Le ransomware (rançongiciel) bloque l'accès à tes données jusqu'au paiement, ce qu'il vaut mieux éviter grâce aux sauvegardes.",
    },
    {
      q: "Tu es sur un Wi-Fi public (gare, café). Quelle est la meilleure pratique ?",
      options: [
        "Faire mes opérations bancaires, c'est pratique.",
        "Éviter les opérations sensibles, ou passer par un VPN de confiance.",
        "Désactiver les mises à jour pour économiser la connexion.",
      ],
      answer: 1,
      why: "Un réseau public n'est pas sous ton contrôle : mieux vaut y éviter les données sensibles.",
    },
    {
      q: "Pourquoi faut-il installer les mises à jour ?",
      options: [
        "Elles corrigent des failles de sécurité.",
        "Elles servent uniquement à changer l'apparence.",
        "Elles ralentissent les virus.",
      ],
      answer: 0,
      why: "Les failles connues sont exploitées par les attaquants : la mise à jour est la protection la plus simple.",
    },
  ];

  function initQuiz() {
    const box = $("[data-quiz]");
    if (!box) return;

    let index = 0;
    let score = 0;

    function showQuestion() {
      const item = QUESTIONS[index];
      box.innerHTML =
        '<p class="quiz-count" aria-live="polite">Question ' + (index + 1) + " sur " + QUESTIONS.length + "</p>" +
        '<h3 id="quiz-q">' + item.q + "</h3>" +
        '<div role="group" aria-labelledby="quiz-q">' +
        item.options.map((text, k) => '<button type="button" class="opt" data-k="' + k + '">' + text + "</button>").join("") +
        "</div>" +
        '<p class="quiz-why" aria-live="polite"></p>' +
        '<button type="button" class="btn" data-next hidden>' +
        (index === QUESTIONS.length - 1 ? "Voir mon résultat" : "Question suivante") +
        "</button>";

      $$(".opt", box).forEach((button) => button.addEventListener("click", () => answer(button, item)));
      $("[data-next]", box).addEventListener("click", () => {
        index += 1;
        index < QUESTIONS.length ? showQuestion() : showResult();
      });
    }

    function answer(button, item) {
      const chosen = Number(button.dataset.k);
      const options = $$(".opt", box);
      options.forEach((opt) => (opt.disabled = true));

      if (chosen === item.answer) {
        score += 1;
        button.classList.add("good");
        button.textContent = "✓ " + button.textContent;
      } else {
        button.classList.add("bad");
        button.textContent = "✗ " + button.textContent;
        options[item.answer].classList.add("good");
        options[item.answer].textContent = "✓ " + options[item.answer].textContent;
      }
      $(".quiz-why", box).textContent = item.why;
      $("[data-next]", box).hidden = false;
      $("[data-next]", box).focus();
    }

    function showResult() {
      const verdict =
        score >= 5 ? "Très bien protégé : continue comme ça."
        : score >= 3 ? "Pas mal, mais relis les bonnes pratiques ci-dessus."
        : "Il y a des points à revoir : reprends les sections ci-dessus puis réessaie.";
      box.innerHTML =
        "<h3>Résultat : " + score + " sur " + QUESTIONS.length + "</h3>" +
        "<p>" + verdict + "</p>" +
        '<button type="button" class="btn" data-restart>Recommencer</button>';
      $("[data-restart]", box).addEventListener("click", () => {
        index = 0;
        score = 0;
        showQuestion();
      });
    }

    showQuestion();
  }

  /* ---------- 6. Visualisation du tri à bulles (algorithmique.html) ---------- */
  function initSort() {
    const box = $("[data-sort]");
    if (!box) return;

    const view = $(".bars", box);
    const status = $("[data-sort-status]", box);
    const shuffleBtn = $("[data-shuffle]", box);
    const runBtn = $("[data-run]", box);
    const SIZE = 14;
    let data = [];
    let running = false;

    const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    // Dessine les barres : "compared" = positions comparées, "sortedCount" = éléments déjà à leur place
    function draw(compared = [], sortedCount = 0) {
      view.innerHTML = data
        .map((value, i) => {
          const classes = ["sbar"];
          if (compared.includes(i)) classes.push("cmp");
          if (i >= data.length - sortedCount) classes.push("sorted");
          return '<div class="' + classes.join(" ") + '" style="height:' + value * 6 + '%"></div>';
        })
        .join("");
    }

    function shuffle() {
      data = Array.from({ length: SIZE }, (_, i) => i + 1);
      for (let i = SIZE - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [data[i], data[j]] = [data[j], data[i]];
      }
      draw();
      status.textContent = "Tableau mélangé. Lance le tri.";
    }

    async function bubbleSort() {
      if (running) return;
      running = true;
      shuffleBtn.disabled = true;
      runBtn.disabled = true;

      for (let end = SIZE - 1; end > 0; end--) {
        for (let i = 0; i < end; i++) {
          draw([i, i + 1], SIZE - 1 - end);
          status.textContent = "Je compare " + data[i] + " et " + data[i + 1] + ".";
          await wait(120);
          if (data[i] > data[i + 1]) {
            [data[i], data[i + 1]] = [data[i + 1], data[i]];
            draw([i, i + 1], SIZE - 1 - end);
            status.textContent = "J'échange les deux valeurs.";
            await wait(120);
          }
        }
      }
      draw([], SIZE);
      status.textContent = "Tableau trié.";
      shuffleBtn.disabled = false;
      runBtn.disabled = false;
      running = false;
    }

    shuffleBtn.addEventListener("click", shuffle);
    runBtn.addEventListener("click", bubbleSort);
    shuffle();
  }

  /* ---------- 7. Boutons « Copier » (bibliothèque de prompts) ---------- */
  function initCopy() {
    $$("[data-copy]").forEach((button) => {
      button.addEventListener("click", async () => {
        const target = document.getElementById(button.dataset.copy);
        if (!target) return;
        const original = button.textContent;
        try {
          await navigator.clipboard.writeText(target.textContent);
          button.textContent = "Copié";
        } catch (e) {
          button.textContent = "Copie impossible";
        }
        setTimeout(() => (button.textContent = original), 1600);
      });
    });
  }

  /* ---------- 8. Convertisseur décimal / binaire / hexadécimal ---------- */
  function initConvert() {
    const dec = $("#conv-dec");
    const bin = $("#conv-bin");
    const hex = $("#conv-hex");
    const message = $("#conv-msg");
    if (!dec || !bin || !hex) return;

    // Pour chaque champ : ce qui est autorisé, et comment lire la valeur
    const fields = {
      dec: { input: dec, pattern: /^\d{1,15}$/, base: 10 },
      bin: { input: bin, pattern: /^[01]{1,50}$/, base: 2 },
      hex: { input: hex, pattern: /^[0-9a-fA-F]{1,12}$/, base: 16 },
    };

    function refresh(source) {
      const field = fields[source];
      const text = field.input.value.trim();

      if (text === "") {
        Object.values(fields).forEach((f) => (f.input.value = ""));
        message.textContent = "";
        return;
      }
      if (!field.pattern.test(text)) {
        message.textContent = "Valeur invalide pour cette base.";
        return;
      }
      message.textContent = "";
      const number = parseInt(text, field.base);
      if (source !== "dec") dec.value = String(number);
      if (source !== "bin") bin.value = number.toString(2);
      if (source !== "hex") hex.value = number.toString(16).toUpperCase();
    }

    Object.keys(fields).forEach((name) => {
      fields[name].input.addEventListener("input", () => refresh(name));
    });
  }

  initProgress();
  initQuiz();
  initSort();
  initCopy();
  initConvert();
})();

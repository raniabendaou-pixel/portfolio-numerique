# Portfolio numérique

- **Nom :** Prénom Nom
- **Filière :** ta filière
- **Objectif du projet :** présenter mes réalisations dans chaque module du semestre sur un site hébergé avec GitHub Pages.

## Modules

- Digital Skills : cybersécurité, prompt engineering, création de contenu
- Développement : Python, langage C, algorithmique
- Systèmes d'exploitation et fondements : systèmes d'exploitation, architecture et électronique
- Développement web côté client : réalisation du site

## Outils utilisés

À compléter : liste des outils (GitHub, VS Code, Claude, Canva, NotebookLM, etc.).

## Site en ligne

https://votrenom.github.io/portfolio-numerique/

## Avant le rendu

- Remplace tous les textes surlignés (classe `fill`) : Prénom Nom, ta filière.
- Remplace chaque bloc « À remplir » par ton propre contenu, puis supprime-le.
- Remplis la fiche « Transparence IA » en bas de chaque page de production.
- Ajoute tes images, audios et vidéos dans le dossier `medias/`, avec un texte alternatif pour chaque image.
